from src.data.preprocess import clean_text
from src.features.match_features import SkillExtractor, parse_years


def test_clean_text():
    assert clean_text("Email: a@b.com  Python, SQL!! http://x.y") == "email python sql"


def test_parse_years():
    assert parse_years("5 years experience") == 5
    assert parse_years("2-5 years", "min") == 2
    assert parse_years("fresher") == 0


def test_skill_extractor():
    ex = SkillExtractor(["python", "machine learning", "c++"])
    assert ex.skills_of("I know Python and machine learning plus C++") == {"python", "machine learning", "c++"}
    assert ex.skills_of("java only") == set()
