"""SmartHire portal.  Run:  streamlit run app/streamlit_app.py"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import streamlit as st
from src.analyze import SmartHire
from src.parsing.resume_parser import extract_text

st.set_page_config(page_title="SmartHire", page_icon="🎯", layout="wide")


@st.cache_resource(show_spinner="Loading models...")
def load_engine():
    return SmartHire()


st.title("🎯 SmartHire - Resume-to-Job Matching & Career Guidance")
st.caption("Classical ML only (TF-IDF, cosine similarity, K-Means, Random Forest / Gradient Boosting). No LLMs.")

try:
    engine = load_engine()
except Exception as e:
    st.error(f"Models not found ({e}). Run `python -m src.train` first.")
    st.stop()

with st.sidebar:
    st.header("Your resume")
    up = st.file_uploader("Upload PDF / DOCX / TXT", type=["pdf", "docx", "txt"])
    pasted = st.text_area("...or paste resume text", height=160)
    n = st.slider("Number of jobs", 5, 25, 10)
    role = st.selectbox("Target role (for skill gap)", ["(auto - predicted)"] + engine.categories())
    go = st.button("Analyze", type="primary")

text = ""
if up is not None:
    text = extract_text(up, up.name)
elif pasted.strip():
    text = pasted

if go and len(text.split()) < 20:
    st.warning("Please upload or paste a resume (at least ~20 words).")
elif go:
    res = engine.analyze(text, n=n, target_role=None if role.startswith("(auto") else role)
    st.session_state["res"] = res

res = st.session_state.get("res")
if res:
    t1, t2, t3, t4 = st.tabs(["📌 Role prediction", "💼 Matching jobs", "🧩 Skill-gap report", "🤖 Mentor"])
    with t1:
        st.subheader("Predicted resume category")
        cols = st.columns(len(res["category"]))
        for c, (name, p) in zip(cols, res["category"]):
            c.metric(name, f"{p:.0%}")
        cl = res["cluster"]
        st.markdown(f"**Job family (cluster {cl['id']}):** {', '.join(cl['titles'])}  \n"
                    f"*Key terms:* {', '.join(cl['terms'])}")
    with t2:
        st.subheader("Top matching jobs")
        df = res["jobs"].rename(columns={"score": "match_score"})
        st.dataframe(df, use_container_width=True, hide_index=True,
                     column_config={"match_score": st.column_config.ProgressColumn("match score", min_value=0, max_value=1),
                                    "fit_probability": st.column_config.ProgressColumn("shortlist probability", min_value=0, max_value=1)})
        st.caption("Match score = TF-IDF cosine similarity. Shortlist probability = supervised fit-predictor.")
    with t3:
        g = res["gap"]
        st.subheader(f"Skill-gap report for: {g['role']}")
        st.progress(g["coverage"], text=f"Coverage of in-demand skills: {g['coverage']:.0%}")
        a, b = st.columns(2)
        a.markdown("#### ✅ Skills you have that are in demand"); a.dataframe(g["have"], hide_index=True)
        b.markdown("#### ❌ In-demand skills to add"); b.dataframe(g["missing"], hide_index=True)
        st.write("Detected skills in your CV:", ", ".join(g["your_skills"]) or "none from vocabulary")
    with t4:
        q = st.text_input("Ask the rule-based mentor", placeholder="What skills am I missing?")
        if q:
            st.info(engine.mentor(q, res))
else:
    st.info("Upload a resume in the sidebar and click **Analyze**.")
