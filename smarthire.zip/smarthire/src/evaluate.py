"""Metrics + plots shared by all models."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
from sklearn.metrics import classification_report, confusion_matrix
from src import config


def classification_summary(y_true, y_pred):
    return classification_report(y_true, y_pred, zero_division=0, output_dict=True)


def plot_confusion(y_true, y_pred, labels, path=None):
    cm = confusion_matrix(y_true, y_pred, labels=labels)
    fig, ax = plt.subplots(figsize=(11, 9))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=labels, yticklabels=labels, ax=ax, cbar=False)
    ax.set_xlabel("Predicted"); ax.set_ylabel("True"); ax.set_title("Resume classifier - confusion matrix")
    plt.xticks(rotation=60, ha="right"); fig.tight_layout()
    fig.savefig(path or config.FIGS / "confusion_matrix.png", dpi=130); plt.close(fig)


def precision_at_k(rec, resume_texts, true_cats, k=10):
    """Fraction of the top-k recommended jobs whose (weak-label) domain equals the resume's category."""
    vals = []
    for t, c in zip(resume_texts, true_cats):
        top = rec.recommend(t, n=k)
        vals.append((top["domain"] == c).mean())
    return float(np.mean(vals))


def plot_elbow_silhouette(df, path=None):
    fig, ax = plt.subplots(1, 2, figsize=(10, 4))
    ax[0].plot(df["k"], df["inertia"], "o-"); ax[0].set_title("Elbow (inertia)"); ax[0].set_xlabel("k")
    ax[1].plot(df["k"], df["silhouette"], "o-", color="tab:green"); ax[1].set_title("Silhouette"); ax[1].set_xlabel("k")
    fig.tight_layout(); fig.savefig(path or config.FIGS / "elbow_silhouette.png", dpi=130); plt.close(fig)


def plot_clusters(Z2, labels, path=None):
    fig, ax = plt.subplots(figsize=(8, 6))
    idx = np.random.RandomState(0).choice(len(Z2), min(6000, len(Z2)), replace=False)
    sc = ax.scatter(Z2[idx, 0], Z2[idx, 1], c=labels[idx], s=4, cmap="tab20")
    ax.set_title("Job clusters (SVD 2-D projection)"); fig.colorbar(sc)
    fig.tight_layout(); fig.savefig(path or config.FIGS / "job_clusters.png", dpi=130); plt.close(fig)


def plot_bar(df, x, y, title, path):
    fig, ax = plt.subplots(figsize=(8, 4)); ax.bar(df[x], df[y]); ax.set_title(title)
    plt.xticks(rotation=30, ha="right"); fig.tight_layout(); fig.savefig(path, dpi=130); plt.close(fig)
