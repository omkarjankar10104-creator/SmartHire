"""Model B (optional) - shortlisting / fit predictor on (resume, job) pair features.

Label (weak supervision): 1 if the job's predicted domain == resume category, else 0.
Negatives mix hard negatives (high cosine, wrong domain) and random jobs.
"""
import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, roc_auc_score
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from src import config
from src.features.match_features import PAIR_FEATURES, pair_features, parse_years

try:
    from xgboost import XGBClassifier
except Exception:  # xgboost optional
    XGBClassifier = None


def build_pairs(resumes, rec, S_jobs, extractor, job_domain, n_pos=5, n_hard=5, n_rand=5, max_resumes=900):
    rng = np.random.RandomState(config.RANDOM_STATE)
    jobs = rec.jobs
    min_years = jobs["experience"].map(lambda x: parse_years(x, "min")).values
    title_tok = jobs["title"].str.lower().str.split().map(set).tolist()
    r = resumes.sample(min(max_resumes, len(resumes)), random_state=config.RANDOM_STATE).reset_index(drop=True)
    R_skill = extractor.matrix(r["resume_text"].str.lower())
    R_X = rec.vec.transform(r["resume_clean"])
    frames = []
    for i, row in r.iterrows():
        cos = (R_X[i] @ rec.X.T).toarray().ravel()
        same = np.where(job_domain == row["category"])[0]
        diff = np.where(job_domain != row["category"])[0]
        pos = rng.choice(same, min(n_pos, len(same)), replace=False) if len(same) else []
        hard = diff[np.argsort(-cos[diff])[:50]]
        hard = rng.choice(hard, min(n_hard, len(hard)), replace=False)
        rnd = rng.choice(diff, min(n_rand, len(diff)), replace=False)
        idx = np.concatenate([pos, hard, rnd]).astype(int)
        f = pair_features(R_skill[i], S_jobs[idx], cos[idx], parse_years(row["resume_text"]), min_years[idx],
                          set(row["resume_clean"].split()), [title_tok[j] for j in idx])
        f["y"] = (job_domain[idx] == row["category"]).astype(int)
        f["resume_id"] = i
        frames.append(f)
    return pd.concat(frames, ignore_index=True)


def train_compare(pairs):
    ids = pairs["resume_id"].unique()
    rng = np.random.RandomState(config.RANDOM_STATE); rng.shuffle(ids)
    test_ids = set(ids[: int(0.2 * len(ids))])
    te = pairs["resume_id"].isin(test_ids)
    Xtr, ytr, Xte, yte = pairs.loc[~te, PAIR_FEATURES], pairs.loc[~te, "y"], pairs.loc[te, PAIR_FEATURES], pairs.loc[te, "y"]
    models = {"LogisticRegression": make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000, class_weight="balanced")),
              "GradientBoosting": GradientBoostingClassifier(random_state=config.RANDOM_STATE)}
    if XGBClassifier is not None:
        models["XGBoost"] = XGBClassifier(n_estimators=200, max_depth=4, learning_rate=0.1, eval_metric="logloss")
    rows, best, best_auc = [], None, -1
    for name, m in models.items():
        m.fit(Xtr, ytr)
        p, pred = m.predict_proba(Xte)[:, 1], m.predict(Xte)
        auc = roc_auc_score(yte, p)
        rows.append({"model": name, "accuracy": accuracy_score(yte, pred), "precision": precision_score(yte, pred),
                     "recall": recall_score(yte, pred), "f1": f1_score(yte, pred), "roc_auc": auc})
        if auc > best_auc:
            best, best_auc, best_name = m, auc, name
    return best, best_name, pd.DataFrame(rows).sort_values("roc_auc", ascending=False)


def save(m):
    joblib.dump(m, config.MODELS / "fit_predictor.pkl")


def load():
    return joblib.load(config.MODELS / "fit_predictor.pkl")
