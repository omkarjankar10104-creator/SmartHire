"""Model A - Resume category classifier: clean text -> TF-IDF -> LR / SVM / RF."""
import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.svm import LinearSVC
from sklearn.calibration import CalibratedClassifierCV
from src import config
from src.data.preprocess import clean_text
from src.features.text_features import make_tfidf


def candidates():
    return {
        "LogisticRegression": LogisticRegression(max_iter=2000, C=10),
        "LinearSVC(calibrated)": CalibratedClassifierCV(LinearSVC(C=1.0), cv=3),
        "RandomForest": RandomForestClassifier(n_estimators=200, n_jobs=-1, random_state=config.RANDOM_STATE),
    }


def train(resumes: pd.DataFrame):
    """Returns best pipeline, comparison table, and the held-out split (X_test, y_test)."""
    X = resumes["resume_text"].map(clean_text)
    y = resumes["category"]
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, stratify=y, random_state=config.RANDOM_STATE)
    rows, best, best_f1 = [], None, -1
    for name, clf in candidates().items():
        pipe = Pipeline([("tfidf", make_tfidf(max_features=15000)), ("clf", clf)]).fit(Xtr, ytr)
        pred = pipe.predict(Xte)
        f1 = f1_score(yte, pred, average="macro")
        rows.append({"model": name, "accuracy": accuracy_score(yte, pred), "macro_f1": f1})
        if f1 > best_f1:
            best, best_f1, best_name = pipe, f1, name
    table = pd.DataFrame(rows).sort_values("macro_f1", ascending=False)
    return best, best_name, table, (Xte, yte)


def predict(pipe, text: str, top=3):
    p = pipe.predict_proba([clean_text(text)])[0]
    order = p.argsort()[::-1][:top]
    return [(pipe.classes_[i], float(p[i])) for i in order]


def save(pipe):
    joblib.dump(pipe, config.MODELS / "classifier.pkl")


def load():
    return joblib.load(config.MODELS / "classifier.pkl")
