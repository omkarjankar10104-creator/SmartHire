"""Core engine - content-based recommender: TF-IDF vectors + cosine similarity -> top-N jobs."""
import joblib
from sklearn.metrics.pairwise import linear_kernel
from src import config
from src.data.preprocess import clean_text
from src.features.text_features import make_tfidf


class JobRecommender:
    def __init__(self):
        self.vec = make_tfidf(max_features=20000)

    def fit(self, jobs):
        self.jobs = jobs.reset_index(drop=True)
        self.X = self.vec.fit_transform(self.jobs["text"])
        return self

    def transform(self, text):
        return self.vec.transform([clean_text(text)])

    def scores(self, text):
        return linear_kernel(self.transform(text), self.X).ravel()

    def recommend(self, text, n=config.TOP_N, domain=None, source=None):
        s = self.scores(text)
        df = self.jobs.assign(score=s)
        if domain:
            df = df[df["domain"] == domain]
        if source:
            df = df[df["source"] == source]
        df = df.sort_values("score", ascending=False)
        df = df.drop_duplicates(subset=["title", "company"]).head(n)
        return df

    def save(self):
        joblib.dump(self, config.MODELS / "recommender.pkl", compress=3)

    @staticmethod
    def load():
        return joblib.load(config.MODELS / "recommender.pkl")
