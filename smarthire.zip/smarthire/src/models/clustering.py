"""Job clustering (K-Means on SVD-reduced TF-IDF), NMF topics, and the skill-gap report."""
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.decomposition import NMF, TruncatedSVD
from sklearn.metrics import silhouette_score
from src import config


def reduce(X, dims=config.SVD_DIMS):
    svd = TruncatedSVD(n_components=dims, random_state=config.RANDOM_STATE)
    Z = svd.fit_transform(X)
    Z /= np.linalg.norm(Z, axis=1, keepdims=True) + 1e-9
    return svd, Z


def choose_k(Z, k_range=config.K_RANGE, sample=6000):
    """Elbow (inertia) + silhouette for each k. Returns DataFrame and suggested k (best silhouette)."""
    rng = np.random.RandomState(config.RANDOM_STATE)
    idx = rng.choice(len(Z), min(sample, len(Z)), replace=False)
    rows = []
    for k in k_range:
        km = KMeans(n_clusters=k, n_init=3, random_state=config.RANDOM_STATE).fit(Z[idx])
        rows.append({"k": k, "inertia": km.inertia_, "silhouette": silhouette_score(Z[idx], km.labels_)})
    df = pd.DataFrame(rows)
    return df, int(df.loc[df["silhouette"].idxmax(), "k"])


def fit_kmeans(Z, k):
    return KMeans(n_clusters=k, n_init=10, random_state=config.RANDOM_STATE).fit(Z)


def cluster_summary(jobs, labels, X, vec, top_terms=8):
    """Name each cluster by its top TF-IDF terms and most common titles."""
    terms = np.array(vec.get_feature_names_out())
    out = {}
    for c in sorted(set(labels)):
        m = labels == c
        centroid = np.asarray(X[m].mean(axis=0)).ravel()
        out[c] = {"size": int(m.sum()),
                  "terms": list(terms[centroid.argsort()[::-1][:top_terms]]),
                  "titles": jobs.loc[m, "title"].str.title().value_counts().head(3).index.tolist()}
    return out


def nmf_topics(X, vec, n_topics=10, top_words=8):
    nmf = NMF(n_components=n_topics, random_state=config.RANDOM_STATE, init="nndsvd", max_iter=300).fit(X)
    terms = np.array(vec.get_feature_names_out())
    return [list(terms[t.argsort()[::-1][:top_words]]) for t in nmf.components_]


# ------------------------- skill-gap -------------------------
def skill_demand(S, mask) -> pd.Series:
    """Share of the selected jobs (mask) that mention each skill. S: jobs x skills binary csr."""
    sub = S[np.where(mask)[0]]
    return pd.Series(np.asarray(sub.mean(axis=0)).ravel())


def skill_gap(demand: pd.Series, vocab, candidate_skills: set, top=15, min_share=0.02):
    """Compare candidate skills with the in-demand skills of a target job group."""
    d = pd.DataFrame({"skill": vocab, "demand_%": (demand.values * 100).round(1)})
    d = d[d["demand_%"] >= min_share * 100].sort_values("demand_%", ascending=False).head(top * 3)
    have = d[d["skill"].isin(candidate_skills)].head(top)
    missing = d[~d["skill"].isin(candidate_skills)].head(top)
    coverage = float(have["demand_%"].sum() / max(d.head(top)["demand_%"].sum(), 1e-9)) if len(d) else 0.0
    return have.reset_index(drop=True), missing.reset_index(drop=True), min(coverage, 1.0)
