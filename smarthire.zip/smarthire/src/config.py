"""Paths, constants and parameters."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RAW, INTERIM, PROCESSED = (ROOT / "data" / d for d in ("raw", "interim", "processed"))
MODELS = ROOT / "models"
FIGS = ROOT / "reports" / "figures"
REPORTS = ROOT / "reports"

RANDOM_STATE = 42
TOP_N = 10
K_RANGE = range(3, 15)
SVD_DIMS = 50
