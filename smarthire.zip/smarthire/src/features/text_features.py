from sklearn.feature_extraction.text import TfidfVectorizer


def make_tfidf(max_features=20000, ngram_range=(1, 2), min_df=2) -> TfidfVectorizer:
    return TfidfVectorizer(max_features=max_features, ngram_range=ngram_range, stop_words="english",
                           sublinear_tf=True, min_df=min_df, token_pattern=r"(?u)\b[\w+#.]{2,}\b")
