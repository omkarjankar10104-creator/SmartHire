"""Skill extraction (vectorised) + resume/job pair features."""
import re
from collections import Counter
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer

PAIR_FEATURES = ["skill_jaccard", "skill_recall", "n_matched", "cosine", "exp_gap", "title_overlap"]
_OK = re.compile(r"^[a-z0-9+#. ]+$")


def build_skill_vocab(jobs: pd.DataFrame, min_count=30, top=500) -> list:
    """Skill vocabulary = frequent items from jobs' comma-separated `skills` column (Indeed has these)."""
    c = Counter()
    for s in jobs["skills"].fillna(""):
        for item in str(s).lower().split(","):
            item = item.strip()
            if 1 < len(item) <= 30 and len(item.split()) <= 3 and _OK.match(item):
                c[item] += 1
    return [k for k, v in c.most_common(top) if v >= min_count]


class SkillExtractor:
    """Binary job/resume x skill matrices via CountVectorizer with a fixed vocabulary."""
    def __init__(self, vocab):
        self.vocab = list(vocab)
        self.cv = CountVectorizer(vocabulary=self.vocab, ngram_range=(1, 3), binary=True,
                                  lowercase=True, token_pattern=r"[a-z0-9+#.]+")

    def matrix(self, texts):
        return self.cv.transform(texts).tocsr()

    def skills_of(self, text) -> set:
        row = self.matrix([text])
        return {self.vocab[i] for i in row.indices}


def parse_years(text, pick="max") -> float:
    """'2-5 years' -> min 2 / max 5; '5+ years' -> 5; no number -> 0."""
    t = str(text).lower()
    rng = re.findall(r"(\d+)\s*(?:-|to)\s*(\d+)", t)
    if rng:
        lo, hi = int(rng[0][0]), int(rng[0][1])
        return float(lo if pick == "min" else hi)
    nums = [int(n) for n in re.findall(r"(\d+)\s*\+?\s*(?:years|yrs|year|yr)", t)]
    return float(max(nums) if pick == "max" else min(nums)) if nums else 0.0


def pair_features(r_skills_row, j_skills_rows, cosines, r_years, j_min_years, r_tokens, j_title_tokens) -> pd.DataFrame:
    """Features for ONE resume vs many jobs. r_skills_row: 1xV csr; j_skills_rows: nxV csr."""
    inter = np.asarray(j_skills_rows.multiply(r_skills_row).sum(axis=1)).ravel()
    n_j = np.asarray(j_skills_rows.sum(axis=1)).ravel()
    n_r = float(r_skills_row.sum())
    union = n_j + n_r - inter
    return pd.DataFrame({
        "skill_jaccard": np.divide(inter, union, out=np.zeros_like(inter, dtype=float), where=union > 0),
        "skill_recall": np.divide(inter, n_j, out=np.zeros_like(inter, dtype=float), where=n_j > 0),
        "n_matched": inter, "cosine": np.asarray(cosines, dtype=float),
        "exp_gap": r_years - np.asarray(j_min_years, dtype=float),
        "title_overlap": [len(t & r_tokens) / max(len(t), 1) for t in j_title_tokens]})
