"""Text cleaning and job-corpus building."""
import re
import pandas as pd

JOB_COLS = ["title", "company", "location", "skills", "description", "experience", "source"]


def clean_text(text) -> str:
    t = str(text).lower()
    t = re.sub(r"http\S+|\S+@\S+", " ", t)
    t = re.sub(r"[^a-z0-9+#./\s-]", " ", t)
    t = re.sub(r"[.\-/](?=\s|$)|(?<=\s)[.\-/]", " ", t)
    return re.sub(r"\s+", " ", t).strip()


def build_job_corpus(frames) -> pd.DataFrame:
    """Merge job DataFrames (already mapped to JOB_COLS) into one clean corpus."""
    df = pd.concat(frames, ignore_index=True)
    for c in JOB_COLS:
        if c not in df:
            df[c] = ""
    df[JOB_COLS] = df[JOB_COLS].fillna("").astype(str)
    df = df[(df["title"].str.strip() != "") & ((df["skills"] + df["description"]).str.len() > 20)]
    df = df.drop_duplicates(subset=["title", "company", "location", "description"]).reset_index(drop=True)
    df["text"] = (df["title"] + " " + df["skills"] + " " + df["skills"] + " " + df["description"].str[:3000]).map(clean_text)
    df["job_id"] = range(len(df))
    return df
