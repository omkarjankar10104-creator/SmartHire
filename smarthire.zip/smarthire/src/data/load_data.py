"""Read the 4 raw datasets from data/raw/ (falls back to synthetic data if they are missing).

data/raw/Resume_Dataset/Resume.csv                      (ID, Resume_str, Resume_html, Category)
data/raw/Naukri_Job_Listings/**/*.ldjson                (job_title, job_description, city, ...)
data/raw/LinkedIn_Job_Postings_2023_2024/postings.csv   (title, description, skills_desc, ...)
data/raw/Indeed__Job_Recommendation_datasets/jobs.csv   (Job Title, Key Skills, Job Experience Required, ...)
"""
import html
import re
import pandas as pd
from src import config
from src.data import sample_data
from src.data.preprocess import JOB_COLS

N_NAUKRI, N_LINKEDIN = 15000, 15000     # sample sizes (keeps the demo fast; raise for bigger corpus)


def _first(pattern):
    hits = sorted(config.RAW.glob(pattern))
    return hits[0] if hits else None


def _strip_html(s) -> str:
    s = html.unescape(str(s))
    s = re.sub(r"<[^>]+>", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def _finish(df, source):
    for c in JOB_COLS:
        if c not in df:
            df[c] = ""
    df["source"] = source
    return df[JOB_COLS]


def load_resumes() -> pd.DataFrame:
    p = _first("**/Resume.csv") or _first("**/*esume*.csv")
    if p is None:
        print("[load_data] Resume dataset not found -> SYNTHETIC resumes")
        return sample_data.make_resumes()
    df = pd.read_csv(p).rename(columns={"Category": "category", "Resume_str": "resume_text", "Resume": "resume_text"})
    df = df[["category", "resume_text"]].dropna()
    df["category"] = df["category"].str.upper().str.strip()
    return df.reset_index(drop=True)


def load_naukri(n=N_NAUKRI):
    p = _first("**/*.ldjson") or _first("**/*aukri*.csv")
    if p is None:
        return None
    df = pd.read_json(p, lines=True, dtype=False) if p.suffix == ".ldjson" else pd.read_csv(p)
    df = df.sample(min(n, len(df)), random_state=config.RANDOM_STATE)
    desc = df["job_description"].map(_strip_html)
    out = pd.DataFrame({
        "title": df["job_title"], "company": df["company_name"], "location": df["city"], "description": desc,
        "experience": desc.str.extract(r"Work Experience\s*([\d\s\-]+?)\s*Years", flags=re.I)[0].fillna("").str.strip().map(
            lambda x: f"{x} years" if x else ""),
        "skills": ""})
    return _finish(out, "naukri")


def load_indeed():
    p = _first("**/jobs.csv")
    if p is None:
        return None
    df = pd.read_csv(p)
    out = pd.DataFrame({
        "title": df["Job Title"], "skills": df["Key Skills"].fillna("").str.replace("|", ",", regex=False),
        "description": (df["Role Category"].fillna("") + ". " + df["Functional Area"].fillna("") + ". " + df["Industry"].fillna("")),
        "experience": df["Job Experience Required"].fillna("").str.replace("yrs", "years")})
    return _finish(out, "indeed")


def load_linkedin(n=N_LINKEDIN):
    p = _first("**/postings.csv")
    if p is None:
        return None
    df = pd.read_csv(p, usecols=["title", "company_name", "location", "description", "skills_desc",
                                 "formatted_experience_level"]).dropna(subset=["title", "description"])
    df = df.sample(min(n, len(df)), random_state=config.RANDOM_STATE)
    out = pd.DataFrame({"title": df["title"], "company": df["company_name"], "location": df["location"],
                        "description": df["description"].map(_strip_html),
                        "experience": df["formatted_experience_level"].fillna(""), "skills": ""})
    return _finish(out, "linkedin")


def load_jobs() -> list:
    frames = [f for f in (load_naukri(), load_linkedin(), load_indeed()) if f is not None]
    if not frames:
        print("[load_data] No job datasets found -> SYNTHETIC jobs")
        j = sample_data.make_jobs(); j["source"] = "synthetic"; frames = [j]
    return frames
