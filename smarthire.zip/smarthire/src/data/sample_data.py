"""Synthetic stand-in data so the whole pipeline runs without Kaggle downloads.
Replace by putting the real CSVs in data/raw/ (see load_data.py)."""
import random
import pandas as pd

DOMAINS = {
    "Data Science": (["Data Scientist", "ML Engineer", "Data Analyst"],
        ["python", "pandas", "numpy", "scikit-learn", "machine learning", "statistics", "tensorflow",
         "sql", "data visualization", "feature engineering", "deep learning", "nlp", "xgboost"]),
    "Web Development": (["Frontend Developer", "Full Stack Developer", "Web Developer"],
        ["html", "css", "javascript", "react", "node.js", "typescript", "angular", "rest api",
         "mongodb", "express", "redux", "webpack", "bootstrap"]),
    "Java Developer": (["Java Developer", "Backend Engineer", "Spring Developer"],
        ["java", "spring boot", "hibernate", "maven", "microservices", "junit", "sql", "jpa",
         "kafka", "rest api", "jenkins", "oop", "mysql"]),
    "DevOps Engineer": (["DevOps Engineer", "Site Reliability Engineer", "Cloud Engineer"],
        ["docker", "kubernetes", "jenkins", "terraform", "aws", "linux", "ansible", "ci/cd",
         "prometheus", "bash", "git", "azure", "monitoring"]),
    "HR": (["HR Executive", "Talent Acquisition Specialist", "HR Manager"],
        ["recruitment", "onboarding", "payroll", "employee engagement", "talent acquisition",
         "performance management", "hris", "labor law", "interviewing", "training", "communication"]),
    "Testing": (["QA Engineer", "Automation Tester", "Test Analyst"],
        ["selenium", "manual testing", "test cases", "jira", "postman", "automation testing",
         "testng", "bug tracking", "regression testing", "api testing", "cucumber", "sql"]),
    "Database": (["Database Administrator", "SQL Developer", "ETL Developer"],
        ["sql", "oracle", "postgresql", "mysql", "stored procedures", "performance tuning",
         "etl", "data warehouse", "backup recovery", "pl/sql", "indexing", "ssis"]),
    "Business Analyst": (["Business Analyst", "Product Analyst", "Systems Analyst"],
        ["requirements gathering", "excel", "power bi", "tableau", "sql", "stakeholder management",
         "user stories", "process mapping", "jira", "documentation", "agile", "uat"]),
}
CITIES = ["Pune", "Bengaluru", "Mumbai", "Hyderabad", "Chennai", "Delhi", "Sangli", "Kolkata"]
COMPANIES = ["Acme Tech", "Nimbus Labs", "Orbit Systems", "BlueRiver", "Kite Software", "Zenith Corp",
             "Pioneer IT", "Lumen Analytics", "Vertex Solutions", "Alpha Works"]
FILLER = ["worked in a cross functional team", "delivered projects on time", "strong problem solving skills",
          "bachelor of engineering", "good communication skills", "completed internship", "team player"]


def make_resumes(per_domain=40, seed=42):
    rnd, rows = random.Random(seed), []
    for dom, (_, skills) in DOMAINS.items():
        others = [s for d, (_, ss) in DOMAINS.items() if d != dom for s in ss]
        for _ in range(per_domain):
            sk = rnd.sample(skills, rnd.randint(5, 9)) + rnd.sample(others, rnd.randint(1, 3))
            yrs = rnd.randint(0, 8)
            text = (f"Skills: {', '.join(sk)}. {rnd.choice(FILLER)}. {yrs} years of experience. "
                    f"{rnd.choice(FILLER)}. Projects using {', '.join(rnd.sample(sk, 3))}.")
            rows.append({"category": dom, "resume_text": text})
    return pd.DataFrame(rows).sample(frac=1, random_state=seed).reset_index(drop=True)


def make_jobs(per_domain=40, seed=7):
    rnd, rows = random.Random(seed), []
    for dom, (titles, skills) in DOMAINS.items():
        for _ in range(per_domain):
            sk = rnd.sample(skills, rnd.randint(5, 8))
            lo = rnd.randint(0, 5)
            rows.append({
                "title": rnd.choice(titles), "company": rnd.choice(COMPANIES), "location": rnd.choice(CITIES),
                "skills": ", ".join(sk),
                "description": f"We are hiring for a role requiring {', '.join(sk)}. {rnd.choice(FILLER)}.",
                "experience": f"{lo}-{lo + rnd.randint(1, 4)} years", "domain": dom,
            })
    return pd.DataFrame(rows).sample(frac=1, random_state=seed).reset_index(drop=True)
