"""One-call resume analysis used by the Streamlit app (and testable without Streamlit)."""
import joblib
import pandas as pd
from src import config
from src.data.preprocess import clean_text
from src.features.match_features import SkillExtractor, pair_features, parse_years
from src.models import classifier, clustering, fit_predictor
from src.models.recommender import JobRecommender


class SmartHire:
    def __init__(self):
        self.clf = classifier.load()
        self.rec = JobRecommender.load()
        c = joblib.load(config.MODELS / "clustering.pkl")
        self.svd, self.km, self.summary, self.topics = c["svd"], c["kmeans"], c["summary"], c["topics"]
        self.vocab, self.S = c["vocab"], c["S"]
        self.ext = SkillExtractor(self.vocab)
        self.fit = fit_predictor.load()
        self.jobs = self.rec.jobs

    def categories(self):
        return list(self.clf.classes_)

    def analyze(self, resume_text, n=10, target_role=None):
        clean = clean_text(resume_text)
        out = {"category": classifier.predict(self.clf, resume_text, top=3)}
        # --- recommendations (unsupervised) ---
        top = self.rec.recommend(resume_text, n=n)
        # --- fit probability (supervised) ---
        idx = top.index.values
        r_skills_row = self.ext.matrix([clean])
        feats = pair_features(r_skills_row, self.S[idx], top["score"].values, parse_years(resume_text),
                              top["experience"].map(lambda x: parse_years(x, "min")).values,
                              set(clean.split()), [set(t.lower().split()) for t in top["title"]])
        top = top.assign(fit_probability=self.fit.predict_proba(feats[fit_predictor.PAIR_FEATURES])[:, 1])
        out["jobs"] = top[["title", "company", "location", "source", "experience", "score", "fit_probability", "domain"]]
        # --- cluster of the resume ---
        z = self.svd.transform(self.rec.transform(resume_text))
        z = z / ((z ** 2).sum() ** 0.5 + 1e-9)
        cid = int(self.km.predict(z)[0])
        out["cluster"] = {"id": cid, **self.summary[cid]}
        # --- skill gap vs target job group ---
        mine = self.ext.skills_of(clean)
        role = target_role or out["category"][0][0]
        mask = (self.jobs["domain"] == role).values
        if mask.sum() < 5:
            mask = (self.jobs["cluster"] == cid).values
        have, missing, cov = clustering.skill_gap(clustering.skill_demand(self.S, mask), self.vocab, mine)
        out["gap"] = {"role": role, "have": have, "missing": missing, "coverage": cov, "your_skills": sorted(mine)}
        return out

    def mentor(self, question, analysis):
        """Rule-based 'mentor' (no LLM): answers from the skill-gap output."""
        q = question.lower()
        g = analysis["gap"]
        if "missing" in q or "improve" in q or "learn" in q or "gap" in q:
            m = g["missing"]["skill"].head(5).tolist()
            return f"For **{g['role']}** roles, your top missing skills are: {', '.join(m) or 'none found'}."
        if "have" in q or "strong" in q:
            return f"Skills of yours in demand for {g['role']}: {', '.join(g['have']['skill'].head(8)) or 'none found'}."
        if "role" in q or "job" in q or "category" in q:
            c = analysis["category"]
            return "Best-fit domains: " + ", ".join(f"{a} ({b:.0%})" for a, b in c)
        if "score" in q or "ready" in q or "coverage" in q:
            return f"Your resume covers about {g['coverage']:.0%} of the in-demand skills for {g['role']}."
        return "Try asking: 'What skills am I missing?', 'What skills do I have?', 'Which role suits me?' or 'How ready am I?'"
