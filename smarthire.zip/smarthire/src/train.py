"""Train everything:  python -m src.train
Reads data/raw -> builds job corpus -> trains classifier, recommender, clusters, fit predictor -> saves models/figures."""
import json
import time
import joblib
import numpy as np
import pandas as pd
from src import config, evaluate
from src.data import load_data, preprocess
from src.features.match_features import SkillExtractor, build_skill_vocab
from src.models import classifier, clustering, fit_predictor
from src.models.recommender import JobRecommender


def step(msg):
    print(f"\n=== {msg} ({time.strftime('%H:%M:%S')})")


def main():
    for d in (config.INTERIM, config.PROCESSED, config.MODELS, config.FIGS):
        d.mkdir(parents=True, exist_ok=True)
    metrics = {}

    step("1. Load + clean data")
    resumes = load_data.load_resumes()
    jobs = preprocess.build_job_corpus(load_data.load_jobs())
    resumes["resume_clean"] = resumes["resume_text"].map(preprocess.clean_text)
    print(f"resumes={len(resumes)}  categories={resumes['category'].nunique()}  jobs={len(jobs)}")
    print(jobs["source"].value_counts().to_dict())
    resumes.to_csv(config.INTERIM / "resumes_clean.csv", index=False)

    step("2. Model A - resume category classifier")
    clf, best_name, table, (Xte, yte) = classifier.train(resumes)
    print(table.to_string(index=False)); print("best:", best_name)
    pred = clf.predict(Xte)
    evaluate.plot_confusion(yte, pred, list(clf.classes_))
    metrics["classifier"] = {"best": best_name, "comparison": table.round(4).to_dict("records"),
                             "report": evaluate.classification_summary(yte, pred)}
    classifier.save(clf)
    table.to_csv(config.REPORTS / "classifier_comparison.csv", index=False)

    step("3. Weak-label job domains with the classifier")
    P = clf.predict_proba(jobs["text"])
    jobs["domain"] = clf.classes_[P.argmax(1)]
    jobs["domain_conf"] = P.max(1)
    jobs.to_csv(config.PROCESSED / "jobs_corpus.csv", index=False)
    print(jobs["domain"].value_counts().head(8).to_dict())

    step("4. Recommender (TF-IDF + cosine)")
    rec = JobRecommender().fit(jobs)
    test_idx = Xte.index
    sample = resumes.loc[test_idx].sample(min(120, len(test_idx)), random_state=config.RANDOM_STATE)
    p10 = evaluate.precision_at_k(rec, sample["resume_text"], sample["category"], k=10)
    p5 = evaluate.precision_at_k(rec, sample["resume_text"], sample["category"], k=5)
    metrics["recommender"] = {"precision@5": p5, "precision@10": p10, "n_eval_resumes": len(sample)}
    print(metrics["recommender"])
    rec.save()
    joblib.dump(rec.vec, config.MODELS / "tfidf_vectorizer.pkl")

    step("5. Skills + clustering + topics")
    vocab = build_skill_vocab(jobs)
    ext = SkillExtractor(vocab)
    S = ext.matrix(jobs["text"])
    print("skill vocab:", len(vocab), vocab[:15])
    svd, Z = clustering.reduce(rec.X)
    kdf, k = clustering.choose_k(Z)
    print(kdf.round(3).to_string(index=False)); print("chosen k =", k)
    evaluate.plot_elbow_silhouette(kdf)
    km = clustering.fit_kmeans(Z, k)
    evaluate.plot_clusters(Z[:, :2], km.labels_)
    summary = clustering.cluster_summary(jobs, km.labels_, rec.X, rec.vec)
    topics = clustering.nmf_topics(rec.X, rec.vec)
    jobs["cluster"] = km.labels_
    rec.jobs["cluster"] = km.labels_
    rec.save()
    metrics["clustering"] = {"k": k, "silhouette": float(kdf.loc[kdf.k == k, "silhouette"].iloc[0]),
                             "clusters": {int(c): v for c, v in summary.items()}, "topics": topics}
    joblib.dump({"svd": svd, "kmeans": km, "summary": summary, "topics": topics, "vocab": vocab, "S": S},
                config.MODELS / "clustering.pkl", compress=3)

    step("6. Model B - fit predictor (optional)")
    pairs = fit_predictor.build_pairs(resumes, rec, S, ext, jobs["domain"].values)
    fp, fp_name, fp_table = fit_predictor.train_compare(pairs)
    print(fp_table.round(4).to_string(index=False)); print("best:", fp_name)
    fit_predictor.save(fp)
    fp_table.to_csv(config.REPORTS / "fit_predictor_comparison.csv", index=False)
    metrics["fit_predictor"] = {"best": fp_name, "comparison": fp_table.round(4).to_dict("records")}

    (config.REPORTS / "metrics.json").write_text(json.dumps(metrics, indent=2, default=float))
    print("\nDone. Models in models/, figures in reports/figures/, metrics in reports/metrics.json")


if __name__ == "__main__":
    main()
