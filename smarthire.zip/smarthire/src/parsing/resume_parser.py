"""Extract text from PDF / DOCX / TXT resumes."""


def extract_text(file_or_path, filename: str = "") -> str:
    name = (filename or str(file_or_path)).lower()
    if name.endswith(".pdf"):
        from pypdf import PdfReader
        return "\n".join((p.extract_text() or "") for p in PdfReader(file_or_path).pages)
    if name.endswith(".docx"):
        from docx import Document
        return "\n".join(p.text for p in Document(file_or_path).paragraphs)
    if hasattr(file_or_path, "read"):
        data = file_or_path.read()
        return data.decode("utf-8", errors="ignore") if isinstance(data, bytes) else data
    with open(file_or_path, encoding="utf-8", errors="ignore") as f:
        return f.read()
