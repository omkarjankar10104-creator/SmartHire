# SmartHire - Resume-to-Job Matching & Career Guidance Engine

End-to-end **classical ML** project (no LLMs): upload a resume -> predicted role, ranked matching jobs,
shortlisting probability, and a skill-gap report. Built on 4 Kaggle datasets (Resume, Naukri, LinkedIn 2023-24, Indeed).

## Setup
```bash
python -m venv venv && source venv/bin/activate     # Windows: venv\Scripts\activate
pip install -r requirements.txt
```
Place the datasets under `data/raw/` (unzipped):
```
data/raw/Resume_Dataset/Resume.csv
data/raw/Naukri_Job_Listings/.../*.ldjson
data/raw/LinkedIn_Job_Postings_2023_2024/postings.csv
data/raw/Indeed__Job_Recommendation_datasets/jobs.csv
```
(If none are present the code falls back to a small synthetic dataset so the pipeline still runs.)

## Run
```bash
python -m src.train                    # build corpus, train all models, save models/ + reports/figures/
streamlit run app/streamlit_app.py     # web portal
python -m pytest tests                 # unit tests
```
Sample sizes (15k Naukri, 15k LinkedIn, all Indeed) are set in `src/data/load_data.py`.

## Mapping to the brief
| Feature | Module | Type |
|---|---|---|
| Resume category classifier (LR / SVM / RF) | `src/models/classifier.py` | Supervised |
| Job recommender (TF-IDF + cosine, top-N) | `src/models/recommender.py` | Unsupervised |
| Job clustering (SVD + K-Means, elbow + silhouette) + NMF topics | `src/models/clustering.py` | Unsupervised |
| Skill-gap report | `src/models/clustering.py` (`skill_gap`) | Unsupervised |
| Fit / shortlisting predictor (LR vs GradientBoosting, XGBoost if installed) | `src/models/fit_predictor.py` | Supervised |
| Rule-based mentor (stretch) | `src/analyze.py` (`mentor`) | Rule-based |
| Metrics & plots | `src/evaluate.py` | - |

## Results (this run)
| Component | Result |
|---|---|
| Classifier (24 classes, 20% test) | Random Forest best: accuracy 0.746, macro-F1 0.684 (SVM 0.714 / 0.671, LR 0.686 / 0.637) |
| Recommender | Precision@5 = 0.49, Precision@10 = 0.485 (120 held-out resumes, weak labels - see below) |
| Clustering | k = 12 chosen by silhouette (0.107); elbow + silhouette plot in `reports/figures/` |
| Fit predictor (held-out resumes) | GradientBoosting: ROC-AUC 0.790, F1 0.585 vs Logistic Regression ROC-AUC 0.625 |

Full numbers: `reports/metrics.json`, `reports/classifier_comparison.csv`, `reports/fit_predictor_comparison.csv`.

## Limitations (include in your report)
- **No ground-truth resume->job labels exist.** Job "domains" are weak labels predicted by the resume classifier, and Precision@K and the fit-predictor labels use them. These numbers are indicative, not absolute. Many jobs get labelled `BUSINESS-DEVELOPMENT` because the 24 resume categories do not cover all job types.
- Resume categories are US-style (livecareer); Naukri/Indeed are Indian listings and LinkedIn is mostly US - domain shift.
- Skill vocabulary comes from Indeed's `Key Skills` column (Naukri skills are not delimited in the raw text), so it is generic (sales, sql, service...). A curated skill list would sharpen the gap report.
- Naukri data is from early 2020; resumes are ~2.5k, so the classifier is limited by data size.
- Fit predictor and skill-gap are optional/derived modules; treat probabilities as relative rankings.

## Stretch ideas
Sentence embeddings instead of TF-IDF, learning-to-rank, curated skill taxonomy, Streamlit Community Cloud deployment.
